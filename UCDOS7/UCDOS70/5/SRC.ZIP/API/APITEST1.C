/* ���⣺������ʾģʽ */
/*
   1    SetDisplayMode  ������ʾģʽ    AH=0
   2    GetDisplayMode  ����ʾģʽ      AX=FF00,BL=0
*/

#include                "dos.h"
#include                "stdio.h"

typedef                 unsigned char   BYTE;
typedef                 unsigned int    WORD;

void SetDisplayMode(BYTE Mode)
{
   union REGS regs;

   regs.h.ah = 0;
   regs.h.al = Mode;
   int86(0x10,&regs,&regs);
}

int GetDisplayMode(void)
{
   union REGS regs;

   regs.x.ax = 0xff00;
   regs.h.bl = 0;
   int86(0x10,&regs,&regs);
   return regs.h.bl;
}

void GotoXY(int Row,int Col)
{
   union REGS regs;

   regs.h.ah = 2;
   regs.h.bh = 0;
   regs.h.dh = Row;
   regs.h.dl = Col;
   int86(0x10,&regs,&regs);
}

void main()
{
   SetDisplayMode(0x8);
   if (GetDisplayMode() == 0x8) {
      GotoXY(20,20);
      printf("%s","֧���ⲿģʽ8: �ֱ���800x600,16ɫ");
      getch();
      }
   SetDisplayMode(0x9);
   if (GetDisplayMode() == 0x9) {
      GotoXY(20,20);
      printf("%s","֧���ⲿģʽ9: �ֱ���1024x768,16ɫ");
      getch();
      }
   SetDisplayMode(0xa);
   if (GetDisplayMode() == 0xa) {
      GotoXY(20,20);
      printf("%s","֧���ⲿģʽA: �ֱ���640x480,256ɫ");
      getch();
      }
   SetDisplayMode(0xb);
   if (GetDisplayMode() == 0xb) {
      GotoXY(20,20);
      printf("%s","֧���ⲿģʽB: �ֱ���800x600,256ɫ");
      getch();
      }
   SetDisplayMode(0xc);
   if (GetDisplayMode() == 0xc) {
      GotoXY(20,20);
      printf("%s","֧���ⲿģʽC: �ֱ���1024x768,256ɫ");
      getch();
      }

   SetDisplayMode(0x3);
   exit();
}
