/* ���⣺��Ļ������ֱ��д�� */
/*
   1    ScrollUpScreen          ��Ļ�Ϲ�        AH=06H
   2    ScrollDownScreen        ��Ļ�¹�        AH=07H
   3    ScrollLeftScreen        ��Ļ���        AX=FF0CH
   4    ScrollRightScreen       ��Ļ�ҹ�        AX=FF0DH
   5    SetDirectVideoStatus    ��ֱ��д��״̬  AX=FF0FH,BL=00H
   6    GetDirectVideoStatus    ��ֱ��д��״̬  AX=FF0FH,BL=80H
*/
#include                "dos.h"
#include                "stdio.h"

typedef                 unsigned char   BYTE;
typedef                 unsigned int    WORD;

void ScrollUpScreen(int Lines,int Color,int R1,int C1,int R2,int C2)
{
   union REGS regs;

   regs.h.ah = 6;
   regs.h.al = Lines;
   regs.h.bh = Color;
   regs.h.ch = R1;
   regs.h.cl = C1;
   regs.h.dh = R2;
   regs.h.dl = C2;
   int86(0x10,&regs,&regs);
}

void ScrollDownScreen(int Lines,int Color,int R1,int C1,int R2,int C2)
{
   union REGS regs;

   regs.h.ah = 7;
   regs.h.al = Lines;
   regs.h.bh = Color;
   regs.h.ch = R1;
   regs.h.cl = C1;
   regs.h.dh = R2;
   regs.h.dl = C2;
   int86(0x10,&regs,&regs);
}

void ScrollLeftScreen(int Lines,int Color,int R1,int C1,int R2,int C2)
{
   union REGS regs;

   regs.x.ax = 0xff0c;
   regs.h.bh = Color;
   regs.h.bl = Lines;
   regs.h.ch = R1;
   regs.h.cl = C1;
   regs.h.dh = R2;
   regs.h.dl = C2;
   int86(0x10,&regs,&regs);
}

void ScrollRightScreen(int Lines,int Color,int R1,int C1,int R2,int C2)
{
   union REGS regs;

   regs.x.ax = 0xff0d;
   regs.h.bh = Color;
   regs.h.bl = Lines;
   regs.h.ch = R1;
   regs.h.cl = C1;
   regs.h.dh = R2;
   regs.h.dl = C2;
   int86(0x10,&regs,&regs);
}

void SetDirectVideoStatus(int EnableDirectVideo)
{
   union REGS regs;

   regs.x.ax = 0xff0f;
   regs.h.bl = 0;
   regs.h.bh = EnableDirectVideo;
   int86(0x10,&regs,&regs);
}

int GetDirectVideoStatus(void)
{
   union REGS regs;

   regs.x.ax = 0xff0f;
   regs.h.bl = 0x80;
   int86(0x10,&regs,&regs);
   return regs.h.al;
}

void FillScreen(BYTE ch,int Color,int R1,int C1,int R2,int C2)
{
   int          Row,Col;

   for (Row = R1; Row <= R2; Row++) {
      for (Col = C1; Col <= C2; Col++) {
         *(char far *)MK_FP(0xb800,(Row*80+Col)*2) = ch;
         *(char far *)MK_FP(0xb800,(Row*80+Col)*2+1) = Color;
         }
      }
}

void SetDisplayMode(BYTE Mode)
{
   union REGS regs;

   regs.h.ah = 0;
   regs.h.al = Mode;
   int86(0x10,&regs,&regs);
}

void main()
{
   int SaveDV;

   SaveDV = GetDirectVideoStatus();
   SetDirectVideoStatus(1);
   SetDisplayMode(0x3);

   FillScreen(0x7f,0x3f,6,20,18,60);
   getch();
   ScrollUpScreen(0,0x17,7,21,17,59);
   getch();
   FillScreen(0x25,0x2e,7,21,17,59);
   ScrollUpScreen(4,0x47,7,21,17,59);
   getch();
   ScrollDownScreen(2,0x5f,7,21,17,59);
   getch();
   ScrollDownScreen(0,0x82,10,22,14,58);
   getch();

   FillScreen(0x5c,0x71,5,10,18,70);
   ScrollLeftScreen(0,0x5f,9,24,13,56);
   getch();
   FillScreen(0x23,0x38,10,25,12,55);
   ScrollLeftScreen(8,0x2e,10,25,12,55);
   getch();
   ScrollRightScreen(4,0x4f,10,25,12,55);
   getch();
   ScrollRightScreen(0,0x17,6,11,17,69);
   getch();

   SetDisplayMode(0x3);
   SetDirectVideoStatus(SaveDV);

}
