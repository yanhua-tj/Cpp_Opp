/* ���⣺�������� */
/*
   1            ReadChar        ��һ���ַ�      AH=00H
   2            CheckKeyboard   �����̻�����  AH=01H
*/
#include                "dos.h"
#include                "stdio.h"

typedef                 unsigned char   BYTE;
typedef                 unsigned int    WORD;

BYTE ReadChar(void)
{
   union REGS regs;

   regs.h.ah = 0;
   int86(0x16,&regs,&regs);
   return regs.h.al;
}

int CheckKeyBoard(void)
{
    union REGS regs;

    regs.h.ah = 1;
    int86(0x16,&regs,&regs);
    return (regs.x.flags & 0x40) ? 0 : 1;
}

void InitPromptLine(void)
{
   union REGS regs;

   regs.x.ax = 0xff07;
   int86(0x16,&regs,&regs);
}

void main()
{
   BYTE         FirstByte,SecondByte;

   InitPromptLine();
   printf("����һ������:");
   while (!CheckKeyBoard());
   FirstByte = ReadChar();
   while (!CheckKeyBoard());
   SecondByte = ReadChar();
   printf("%c%c\n",FirstByte,SecondByte);
   printf("���뺺��Ϊ��%c%c\n",FirstByte,SecondByte);
   printf("����Ϊ%2x%2xh\n",FirstByte,SecondByte);
   while (CheckKeyBoard()) ReadChar();
}
