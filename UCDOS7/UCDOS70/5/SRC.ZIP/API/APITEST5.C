/* ���⣺��ʾ����ʾ���� */
/*
   1    SetPromptLineColor      ����ʾ����ɫ    AX=FF0FH,BL=8BH
   2    GetPromptLineColor      ����ʾ����ɫ    AX=FF0FH,BL=0BH
   3    ClearPromptLine         ����ʾ��        AX=FF10H,BL=00H
   4    WritePromptMoreChar     д��ʾ���ַ�    AX=FF10H,BL=01H
   5    SetPromptCursor         ����ʾ�й��    AX=FF10H,BL=02H
   6    WritePromptChar         д��ʾ���ַ�    AX=FF10H,BL=03H
   7    InitPromptLine          ������ʾ��      AX=FF07H,INT16H
   8    DispPromptStr           д�����ַ���    AX=FF08H,INT16H
   9    DisablePromptLine       ��ֹ��ʾ��      AX=FF0BH,INT16H
*/
#include                "dos.h"
#include                "stdio.h"

typedef                 unsigned char   BYTE;
typedef                 unsigned int    WORD;

void SetPromptLineColor(int Color1,int Color2,int Color3,int Color4)
{
   union REGS regs;

   regs.x.ax = 0xff0f;
   regs.h.bl = 0x8b;
   regs.h.cl = Color1;
   regs.h.ch = Color2;
   regs.h.dl = Color3;
   regs.h.dh = Color4;
   int86(0x10,&regs,&regs);
}

void GetPromptLineColor(int *Color1,int *Color2,int *Color3,int *Color4)
{
   union REGS regs;

   regs.x.ax = 0xff0f;
   regs.h.bl = 0x0b;
   int86(0x10,&regs,&regs);
   *Color1 = (int)regs.h.al;
   *Color2 = (int)regs.h.ah;
   *Color3 = (int)regs.h.dl;
   *Color4 = (int)regs.h.dh;
}

void ClearPromptLine(int Color)
{
   union REGS regs;

   regs.x.ax = 0xff10;
   regs.h.bl = 0;
   regs.h.bh = Color;
   int86(0x10,&regs,&regs);
}

void WritePromptMoreChar(BYTE ch,int Color,int Count)
{
   union REGS regs;

   regs.x.ax = 0xff10;
   regs.h.bl = 1;
   regs.h.bh = Color;
   regs.x.cx = Count;
   regs.h.dl = ch;
   int86(0x10,&regs,&regs);
}

void SetPromptCursor(int CurPos)
{
   union REGS regs;

   regs.x.ax = 0xff10;
   regs.h.bl = 2;
   regs.h.dl = CurPos;
   int86(0x10,&regs,&regs);
}

void WritePromptChar(BYTE ch,int Color)
{
   union REGS regs;

   regs.x.ax = 0xff10;
   regs.h.bl = 3;
   regs.h.bh = Color;
   regs.h.dl = ch;
   int86(0x10,&regs,&regs);
}

void InitPromptLine(void)
{
   union REGS regs;

   regs.x.ax = 0xff07;
   int86(0x16,&regs,&regs);
}

void DispPromptStr(BYTE * SelectString)
{
   _AX = 0xff08;
   _DX = FP_OFF(SelectString);
   geninterrupt(0x16);
}

void DisablePromptLine(void)
{
   union REGS regs;

   regs.x.ax = 0xff0b;
   int86(0x16,&regs,&regs);
}

void main()
{
    int         i,Color1,Color2,Color3,Color4;
    BYTE        PmtStr[] = " ϣ������ϵͳ��UCDOS 6.0����׼��";
    BYTE        InputStr[] = "hello!       ";

    GetPromptLineColor(&Color1,&Color2,&Color3,&Color4);

    SetPromptLineColor(0x17,0x1e,0x1c,0x1f);
    InitPromptLine();
    getchar();
    DispPromptStr("1�� 2ʾ 3�� 4�� 5ʾ 6�� 7�� 8�� 9�� 0��");
    SetPromptCursor(15);
    for (i = 0; i < 13; i++) {
       WritePromptChar(InputStr[i],0x1c);
       }
    getch();

    ClearPromptLine(0x1d);
    SetPromptCursor(0);
    WritePromptMoreChar('*',0x5f,80);
    SetPromptCursor(20);
    for (i = 0; i < strlen(PmtStr); i++) {
       WritePromptChar(PmtStr[i],(PmtStr[i] > 0xa0 ? 0x70 : 0x74));
       }
    getch();

    SetPromptLineColor(Color1,Color2,Color3,Color4);
    DisablePromptLine();
}
