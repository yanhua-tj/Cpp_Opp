/* ���⣺д����� */
/*
   1    SetPixel        д��            AH=0CH
   2    GetPixel        ����            AH=0DH
*/
#include                "dos.h"
#include                "stdio.h"

typedef                 unsigned char   BYTE;
typedef                 unsigned int    WORD;

void SetPixel(int Col,int Row,int Color)
{
   union REGS regs;

   regs.h.ah = 0xc;
   regs.h.al = Color;
   regs.x.cx = Col;
   regs.x.dx = Row;
   int86(0x10,&regs,&regs);
}

int GetPixel(int Col,int Row)
{
   union REGS regs;

   regs.h.ah = 0xd;
   regs.x.cx = Col;
   regs.x.dx = Row;
   int86(0x10,&regs,&regs);
   return regs.h.al;
}

void SetDisplayMode(BYTE Mode)
{
   union REGS regs;

   regs.h.ah = 0;
   regs.h.al = Mode;
   int86(0x10,&regs,&regs);
}

void EnableCursor(void)
{
   union REGS regs;

   regs.x.ax = 0xff01;
   regs.h.bl = 1;
   regs.h.bh = 1;
   int86(0x10,&regs,&regs);
}

void DisableCursor(void)
{
   union REGS regs;

   regs.x.ax = 0xff01;
   regs.h.bl = 1;
   regs.h.bh = 0;
   int86(0x10,&regs,&regs);
}


void main()
{
   int          i,j;

   SetDisplayMode(0x3);
   DisableCursor();

   for (i = 0; i < 480; i++) {
      SetPixel(80+i,i,7);
      SetPixel(80+i,480-i,7);
      SetPixel(80+i,0,4);
      SetPixel(80+i,479,4);
      SetPixel(80,i,4);
      SetPixel(559,i,4);
      }
   getch();
   for (i = 0; i < 480; i++) {
      SetPixel(80+i,i,GetPixel(80+i,i) ^ 7);
      SetPixel(80+i,480-i,GetPixel(80+i,480-i) ^ 7);
      SetPixel(80+i,0,0x84);
      SetPixel(80+i,479,0x84);
      SetPixel(80,i,0x84);
      SetPixel(559,i,0x84);
      }
   getch();

   EnableCursor();
   SetDisplayMode(0x3);
}
