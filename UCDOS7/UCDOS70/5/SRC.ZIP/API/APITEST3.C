/* ���⣺������ʾ */
/*
   1    WriteChineseChar    д����(������)      AH=09H
   2    WriteCharNoAttr     д����(������)      AH=0AH
   3    WriteChineseString  д���ִ�(TTY��ʽ)   AH=0EH
   4    WriteChineseStrApp  д���ִ�(������)    AH=13H
*/

#include                "dos.h"
#include                "stdio.h"

typedef                 unsigned char   BYTE;
typedef                 unsigned int    WORD;

void GotoXY(int Row,int Col);
void WriteChineseChar(int Row,int Col,int Color,WORD Hz)
{
   union REGS regs;

   GotoXY(Row,Col);
   regs.h.ah = 9;
   regs.h.al = Hz & 0xff;
   regs.h.bh = 0;
   regs.h.bl = Color;
   regs.x.cx = 1;
   int86(0x10,&regs,&regs);
   GotoXY(Row,Col+1);
   regs.h.ah = 9;
   regs.h.al = Hz >> 8;
   regs.h.bh = 0;
   regs.h.bl = Color;
   regs.x.cx = 1;
   int86(0x10,&regs,&regs);
}

void WriteCharNoAttr(int Row,int Col,BYTE ch)
{
   union REGS regs;

   GotoXY(Row,Col);
   regs.h.ah = 0xa;
   regs.h.al = ch;
   regs.h.bh = 0;
   regs.x.cx = 1;
   int86(0x10,&regs,&regs);
}

void WriteChineseString(int Row,int Col,BYTE *HzString)
{
   union REGS regs;

   GotoXY(Row,Col);
   while (*HzString) {
      regs.h.ah = 0xe;
      regs.h.al = *HzString++;
      regs.h.bh = 0;
      int86(0x10,&regs,&regs);
      }
}

void WriteChineseStrApp(int Row,int Col,int Color,BYTE far *HzString)
{
   _BX = Color & 0xff;
   _DX = (Row << 8) + (Col & 0xff);
   _CX = strlen(HzString);
   _BP = FP_OFF(HzString);
   _ES = _DS;
   _AX = 0x1300;
   geninterrupt(0x10);
}

void SetDisplayMode(BYTE Mode)
{
   union REGS regs;

   regs.h.ah = 0;
   regs.h.al = Mode;
   int86(0x10,&regs,&regs);
}

void GotoXY(int Row,int Col)
{
   union REGS regs;

   regs.h.ah = 2;
   regs.h.bh = 0;
   regs.h.dh = Row;
   regs.h.dl = Col;
   int86(0x10,&regs,&regs);
}

void main()
{
   int          i;
   WORD         Hz;
   BYTE         s[] = "ϣ������ϵͳ";

   SetDisplayMode(0x3);

   for (i = 0; i < 6; i++) {
      WriteChineseChar(12,20+i*2,0x4F,*(WORD *)&s[i*2]);
      }

   WriteChineseString(14,20,"TTY��ʽ��ʾ�ĺ����ַ���");

   WriteChineseStrApp(16,20,0x3e,"����һ������DOS ");

   WriteCharNoAttr(16,35,'!');

   getch();
   SetDisplayMode(0x3);

}
