/* ���⣺16X16�����ֿ⣬UCDOSģ��ʶ�� */
/*
   1    IsUcdosResident       UCDOSפ���ڴ�     AX=DB00H,INT 2FH
   2    QueryModuleResident   ��ѯģ���Ƿ�װ  AH=01H  ,INT 79H
   3    ReadDot               ��UCDOS��ʾ�ֿ�            INT 7FH
*/

#include                <dos.h>
#include                <stdio.h>

int IsUcdosResident(void)
{
   union REGS regs;

   regs.x.ax = 0xdb00;
   int86(0x2f,&regs,&regs);
   return regs.x.bx == 0x5450;
}

int QueryModuleResident(int ModuleNo)
{
   union REGS regs;

   if (!IsUcdosResident()) return 0;
   regs.h.ah = 0;
   regs.h.al = ModuleNo;
   int86(0x79,&regs,&regs);
   return regs.x.flags & 0x40 ? 1 : 0;
}

void ReadDot(char *ChineseCode,char *DotBuf)
{
   union REGS           regs;

   regs.h.dh=ChineseCode[0];
   regs.h.dl=ChineseCode[1];

   int86(0x7f,&regs,&regs);                     /* ���� DX:0 Ϊ�ֿ����ݵ�ַ */
   movedata(regs.x.dx, 0, FP_SEG(DotBuf), FP_OFF(DotBuf), 32);
}

void SetDisplayMode(int Mode)
{
   union REGS regs;

   regs.h.ah = 0;
   regs.h.al = Mode;
   int86(0x10,&regs,&regs);
}

void SetPixel(int Col,int Row,int Color)
{
   union REGS regs;

   regs.h.ah = 0xc;
   regs.h.al = Color;
   regs.x.cx = Col;
   regs.x.dx = Row;
   int86(0x10,&regs,&regs);
}

/******************************************************************************
    ����˵��:   x,y             ��ʾ���ֵ����Ͻ�����
                FrColor         ��ʾ���ֵ�ǰ��ɫ
                BgColor         ��ʾ���ֵı���ɫ
                ChineseCode     ����ʾ�ĺ���
******************************************************************************/
void DispChinese(int x,int y,int FrColor,int BgColor,char *ChineseCode)
{
   unsigned char        DotBuf[32],c;
   int                  i,j;

   ReadDot(ChineseCode,DotBuf);

   for (i=0;i<16;i++){
      c=DotBuf[i*2];
      for (j=0;j<8;j++){
         if (c & 0x80) SetPixel(x+j,y+i,FrColor);
         else SetPixel(x+j,y+i,BgColor);
         c=c<<1;
      }

      c=DotBuf[i*2+1];
      for (j=0;j<8;j++){
         if (c & 0x80) SetPixel(x+j+8,y+i,FrColor);
         else SetPixel(x+j+8,y+i,BgColor);
         c=c<<1;
      }
   }
}

void main(void)
{

   if (!QueryModuleResident(0x00)) { /* 0x00 ��RD16��ģ��� */
      printf("Rd16 not in memory!\n");
      exit();
      }
   SetDisplayMode(3);
   DispChinese(120,120,15,1,"ϣ");
   DispChinese(160,120,15,1,"��");
   getch();
   SetDisplayMode(3);
}
