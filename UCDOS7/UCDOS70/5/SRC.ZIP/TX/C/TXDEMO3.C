/*----------------------------------------------------------------------------
�ļ�:	TXDEMO3.C
����:	������ʾͼ�������ʾ����
----------------------------------------------------------------------------*/
#include		"txapi.c"

void InitDemoScreen(int Color)
{
   SetFillStyle(0);
   SetColor(Color);
   Bar(0,0,639,449);
   SetColor(15);
   Rectangle(0,0,639,449);
}

void DemoImage(void)
{
   int			x,y,ImgWide,ImgHigh,i;

   Cls(0);
   ImgWide=160;ImgHigh=188;
   SetPaletteMode(TRUE);
   PutImage(100,100,"TEST.PCX");
   GetImage(105,100,100+ImgWide-1,100+ImgHigh-1,"$0");
   SetPaletteMode(FALSE);
   while (!kbhit()){
      x=random(640-ImgWide);
      y=random(450-ImgHigh);
      PutImage(x,y,"$0");
   }
   SetPaletteMode(TRUE);
   getch();
}

void DemoScaleImage(void)
{
   int			i;

   Cls(0);
   SetPaletteMode(FALSE);
   for (i=1;i<32;i++){
      SetImageScale(i,i);
      PutImage(0,0,"$0");
   }
   getch();

   Cls(0);
   SetImageScale(16,16);
   for (i=10;i<225;i+=2){
      PutImageInWin(320-i,225-i,i*2,i*2,"$0");
   }
   getch();

   Cls(0);
   for (i=20;i<440;i+=10){
      PutImageInWin(100,0,i,450,"$0");
   }
   getch();
   SetPaletteMode(TRUE);
}

void main(void)
{
   if (!CheckTX()){
      printf("Please run TX first\n\7");
      exit(5);
   }
   if (!IsChineseMode(10)){
      printf("��ʾ��������֧�� 640x480x256 ��ʾ��ʽ\7\n");
      printf("��ʹ�� SETUP ����ѡ����ȷ�� Super VGA ��ʾ��ʽ����ִ��\n");
      exit(5);
   }

   SetVideoMode(10);
   DemoImage();
   DemoScaleImage();
   SetVideoMode(3);
}
