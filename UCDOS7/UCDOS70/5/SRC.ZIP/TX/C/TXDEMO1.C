/*----------------------------------------------------------------------------
�ļ�:	TXDEMO1.C
����:	������ʾ��ͼ������ʾ����
----------------------------------------------------------------------------*/
#include		"txapi.c"

void InitDemoScreen(int Color)
{
   SetFillStyle(0);
   SetColor(Color);
   Bar(0,0,639,449);
   SetColor(15);
   Rectangle(0,0,639,449);
}

void DemoDot(void)
{
   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      PutPixel(random(640-2)+1,random(450-2)+1);
   }
   getch();
}

void DemoLine(void)
{
   int			x1,y1,x2,y2;

   InitDemoScreen(0);
   SetWriteMode(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      x1=random(640-2)+1;
      y1=random(450-2)+1;
      x2=640-x1;
      y2=450-y1;
      Line(x1,y1,x2,y2);
      delay(50);
   }
   getch();

   while (!kbhit()){
      SetColor(random(15)+1);
      x1=random(640-2)+1;
      y1=random(450-2)+1;
      x2=random(640-2)+1;
      y2=random(450-2)+1;
      Line(x1,y1,x2,y2);
   }
   getch();
}

void DemoRectangle(void)
{
   int			x1,y1,x2,y2;

   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      x1=random(640-2)+1;
      y1=random(450-2)+1;
      x2=random(640-2)+1;
      y2=random(450-2)+1;
      Rectangle(x1,y1,x2,y2);
      delay(100);
   }
   getch();
}

void DemoBar(void)
{
   int			x1,y1,x2,y2;

   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      x1=random(640-2)+1;
      y1=random(450-2)+1;
      x2=random(640-2)+1;
      y2=random(450-2)+1;
      SetFillStyle(random(12));
      Bar(x1,y1,x2,y2);
      SetColor(15);
      Rectangle(x1,y1,x2,y2);
   }
   getch();
}

void DemoUserPattern(void)
{
   int			x1,y1,x2,y2,i;
   unsigned char	Pattern[8];

   InitDemoScreen(0);
   SetFillStyle(13);
   while (!kbhit()){
      SetColor(random(15)+1);
      x1=random(640-2)+1;
      y1=random(450-2)+1;
      x2=random(640-2)+1;
      y2=random(450-2)+1;
      for (i=0;i<8;i++) Pattern[i]=random(256);
      SetFillPattern(Pattern);
      Bar(x1,y1,x2,y2);
      SetColor(15);
      Rectangle(x1,y1,x2,y2);
      delay(200);
   }
   getch();
}

void DemoCircle(void)
{
   int			x,y,r;

   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      x=random(640-2)+1;
      y=random(450-2)+1;
      r=random(50)+10;
      if (x+r >= 639 || y+r >= 449) continue;
      if (x-r <= 0 || y-r <= 0) continue;
      Circle(x,y,r);
      delay(100);
   }
   getch();
}

void DemoEllipse(void)
{
   int			x,y,xr,yr;

   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      x=random(640-2)+1;
      y=random(450-2)+1;
      xr=random(50)+10;
      yr=random(50)+10;
      if (x+xr >= 639 || y+yr >= 449) continue;
      if (x-xr <= 0 || y-yr <= 0) continue;
      Ellipse(x,y,0,360,xr,yr);
      delay(100);
   }
   getch();
}

void DemoArc(void)
{
   int			x,y,sa,ea,r;

   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(random(15)+1);
      x=random(640-2)+1;
      y=random(450-2)+1;
      sa=random(360-20)+1;
      ea=random(360-20)+1;
      r=random(50)+20;
      if (x+r >= 639 || y+r >= 449) continue;
      if (x-r <= 0 || y-r <= 0) continue;
      if (abs(sa-ea) < 50) continue;
      Arc(x,y,sa,ea,r);
      delay(100);
   }
   getch();
}

void DemoPieSlice(void)
{
   int			x,y,sa,ea,r;

   InitDemoScreen(0);
   while (!kbhit()){
      SetColor(15);
      x=random(640-2)+1;
      y=random(450-2)+1;
      sa=random(360-20)+1;
      ea=random(360-20)+1;
      r=random(50)+20;
      if (x+r >= 639 || y+r >= 449) continue;
      if (x-r <= 0 || y-r <= 0) continue;
      if (abs(sa-ea) < 50) continue;
      SetFillStyle(random(12));
      PieSlice(x,y,sa,ea,r,random(14)+1);
      delay(100);
   }
   getch();
}

void DemoScale(void)
{
   int			i;

   InitDemoScreen(0);
   SetScale(16);
   DefineMacro("l100,100,200,200lt400,160lt100,100");
   SetWriteMode(1);
   for (i=0;i<30;i++){
      SetScale(i);
      ExecuteMacro();
      if (i==29) break;
      delay(100);
      ExecuteMacro();
   }
   getch();
   for (i=29;i>=0;i--){
      SetScale(i);
      ExecuteMacro();
      if (i==29) continue;
      delay(100);
      ExecuteMacro();
   }
   SetWriteMode(0);
   SetScale(16);
   getch();
}

void main(void)
{
   if (!CheckTX()){
      printf("Please run TX first\n\7");
      exit(5);
   }

   SetVideoMode(0x12);
   DemoDot();
   DemoLine();
   DemoRectangle();
   DemoBar();
   DemoUserPattern();
   DemoCircle();
   DemoEllipse();
   DemoArc();
   DemoPieSlice();
   DemoScale();
   SetVideoMode(3);
}
