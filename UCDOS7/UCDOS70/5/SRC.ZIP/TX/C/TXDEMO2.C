/*----------------------------------------------------------------------------
�ļ�:	TXDEMO2.C
����:	������ʾ������ʾ������ʾ
----------------------------------------------------------------------------*/
#include		"txapi.c"

void InitDemoScreen(int Color)
{
   SetFillStyle(0);
   SetColor(Color);
   Bar(0,0,639,449);
   SetColor(15);
   Rectangle(0,0,639,449);
}

void DemoFont(void)
{
   int			i;

   InitDemoScreen(1);
   SetTextWriteMode(1);
   SetFontSize(96,96);
   SetFont(2);

   SetTextColor(4,1);
   for (i=0;i<3;i++){
      OutTextxy(32-i,80-i,"ϣ������ϵͳ");
      OutTextxy(104-i,270-i,"UCDOS 6.0");
   }
   SetTextColor(14,1);
   OutTextxy(32-i,80-i,"ϣ������ϵͳ");
   OutTextxy(104-i,270-i,"UCDOS 6.0");
   SetTextWriteMode(0);
   getch();

   InitDemoScreen(1);
   SetFontSize(48,48);
   SetTextWriteMode(1);
   SetFillStyle(0);
   SetTextColor(15,1);

   SetColor(8);
   Bar(10,40,509,105);
   SetColor(15);
   Rectangle(10-1,40-1,509+1,105+1);
   SetFont(0);
   OutTextxy(20,50,"���Ƶ��豸�޹����ں�");

   SetColor(3);
   Bar(10+35,40+96,509+35,105+96);
   SetColor(15);
   Rectangle(10-1+35,40-1+96,509+1+35,105+1+96);
   SetFont(1);
   OutTextxy(20+35,50+96,"�߶ȵ��ȶ����������");

   SetColor(4);
   Bar(10+35*2,40+96*2,509+35*2,105+96*2);
   SetColor(15);
   Rectangle(10-1+35*2,40-1+96*2,509+1+35*2,105+1+96*2);
   SetCharSpace(3);
   SetFont(2);
   OutTextxy(20+35*2,50+96*2,"�걸�����������ϵ");

   SetColor(5);
   Bar(10+35*3,40+96*3,509+35*3,105+96*3);
   SetColor(15);
   Rectangle(10-1+35*3,40-1+96*3,509+1+35*3,105+1+96*3);
   SetFont(3);
   OutTextxy(20+35*3,50+96*3,"ǿ���Ķ��ο���֧��");

   SetTextWriteMode(0);
   SetCharSpace(0);
   getch();

   InitDemoScreen(1);
   SetFont(0);
   SetFontSize(320-2,450-2);
   SetTextColor(15,8);
   OutTextxy(1,1,"ϣ��");
   getch();
}

void main(void)
{
   if (!CheckTX()){
      printf("Please run TX first\n\7");
      exit(5);
   }

   SetVideoMode(0x12);
   DemoFont();
   SetVideoMode(3);
}
